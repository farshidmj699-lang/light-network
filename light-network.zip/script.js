// فایل اسکریپت اصلی
console.log('Light network started');